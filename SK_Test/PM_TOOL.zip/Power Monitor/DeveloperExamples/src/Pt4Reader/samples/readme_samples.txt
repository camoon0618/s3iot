Included is a sample PT4 and corresponding CD4 file.
You can open the PT4 via the Power Tool application to explore the features of the GUI.


Generated with PowerMonitor v 4.0.4.6. FW v 20.
